/**Ficheito .c que contem todos os ficheiros .h e .c necessarios ao funcionamento do programa*/

#include <SDL2/SDL.h>
#include <SDL2/SDL_ttf.h>
#include <SDL2/SDL_image.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>

#include "Structs.h"
#include "Constants.h"
#include "Functions_declaration.h"
#include "Functions_defenition.c"
