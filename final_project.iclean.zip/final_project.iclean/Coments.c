/**
Este trabalho foi realizado pelo aluno Carlos Silva, numero 81323, e pelo aluno Sergio Marinheiro, munero 81332, no ambito da U.C. de Programaçao. Sendo
o projecto final de programaçao neste trabalho foi necessario todo o conhecimento adquirido ao longo da U.C. de Programaçao. Este trabalho tem como objectivo
a criaçao de um programa que simule o funcionamento de varios robots do tipo "RoombaTM" que tem como objectivo a limpeza de uma sala defenida num ficheiro. Este
programa tambem permite todas as funcionalidades requeridas no guia.

MANUAL DE UTILIZAÇAO

q - Termina a simulaçao e sai da aplicaçao.

i - Reinicia a simulaçao.

p - Pausa a simulaçao.

Setas UP/DOWN - Aumentam ou diminuem a velociade da simulaçao.

a - Adiciona robot, apenas quando a simulaçao estiver em pausa, na posiçao do mapa indicada pelo clique do rato.

e - Escreve um ficheiro com os nomes dos robots, o numero de quadrados limpos e o numero de quadrados percurridos.

o - Adiciona obstaculo, apenas quando a simulaçao estiver em pause, na posiçao do mapa indicada pelo clique do rato.

x - Posicionado no canto da aplicaçao pode ser clicado tendo o mesmo efeito do butao q.

- - Posicionado no canto da aplicaçao pode ser clicado para diminuir a aplicaçao.
*/
